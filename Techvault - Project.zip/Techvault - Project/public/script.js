document.getElementById('loginForm')?.addEventListener('submit', function(event) {
    event.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
           
            localStorage.setItem('user', JSON.stringify(data.user));
            
            window.location.href = 'dashboard.html';
        } else {
            alert('Login failed: ' + data.message);
        }
    })
    .catch((error) => {
        console.error('Error:', error);
        alert('An error occurred. Please try again.');
    });
});


document.getElementById('registerForm')?.addEventListener('submit', function(event) {
    event.preventDefault();

  
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

   
    if (password !== confirmPassword) {
        alert('Passwords do not match!');
        return;
    }


    fetch('/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, email, password }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Registration successful!');
          
            window.location.href = '/index.html'; 
        } else {
            alert('Registration failed: ' + data.message);
        }
    })
    .catch((error) => {
        console.error('Error:', error);
        alert('An error occurred. Please try again.');
    });
});


function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('active');
}


document.getElementById('sidebarToggle')?.addEventListener('click', toggleSidebar);

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('active');
}


document.querySelector('.navbar-toggler').addEventListener('click', toggleSidebar);


document.getElementById('addAssetForm')?.addEventListener('submit', function(event) {
    event.preventDefault();

    const assetName = document.getElementById('assetName').value;
    const assetCategory = document.getElementById('assetCategory').value;
    const assetQuantity = document.getElementById('assetQuantity').value;


    const assetList = document.querySelector('tbody');
    const newRow = `
        <tr>
            <td>
                <img src="https://barcode.tec-it.com/barcode.ashx?data=ASSET${Math.floor(Math.random() * 1000)}&code=Code128&dpi=96" alt="Barcode" style="height: 40px;">
            </td>
            <td>${assetName}</td>
            <td>${assetCategory}</td>
            <td>${assetQuantity}</td>
            <td><span class="badge bg-success">In Stock</span></td>
            <td>
                <button class="btn btn-sm btn-warning me-2" data-bs-toggle="modal" data-bs-target="#editAssetModal">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-sm btn-danger" onclick="deleteAsset(this)">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
    `;
    assetList.insertAdjacentHTML('beforeend', newRow);

  
    const addAssetModal = bootstrap.Modal.getInstance(document.getElementById('addAssetModal'));
    addAssetModal.hide();

    event.target.reset();
});


function deleteAsset(button) {
    const row = button.closest('tr');
    row.remove();
}


document.getElementById('editAssetForm')?.addEventListener('submit', function(event) {
    event.preventDefault();

    const assetName = document.getElementById('editAssetName').value;
    const assetCategory = document.getElementById('editAssetCategory').value;
    const assetQuantity = document.getElementById('editAssetQuantity').value;

   
    const row = document.querySelector('tbody tr'); 
    row.cells[1].textContent = assetName;
    row.cells[2].textContent = assetCategory;
    row.cells[3].textContent = assetQuantity;


    const editAssetModal = bootstrap.Modal.getInstance(document.getElementById('editAssetModal'));
    editAssetModal.hide();

    event.target.reset();
});

let scannedBarcode = null;


function initializeBarcodeScanner() {
    Quagga.init({
        inputStream: {
            name: "Live",
            type: "LiveStream",
            target: document.querySelector("#barcode-scanner"),
            constraints: {
                width: 640,
                height: 480,
                facingMode: "environment",
            },
        },
        decoder: {
            readers: ["code_128_reader"], 
        },
    }, function (err) {
        if (err) {
            console.error("Failed to initialize Quagga:", err);
            return;
        }
        Quagga.start();
    });

    
    Quagga.onDetected(function (result) {
        scannedBarcode = result.codeResult.code;
        alert(`Barcode scanned: ${scannedBarcode}`);

        
        document.getElementById('forOutButton').disabled = false;
        document.getElementById('forReturnButton').disabled = false;
    });
}


document.getElementById('forOutButton')?.addEventListener('click', function () {
    if (!scannedBarcode) return;

    const assetRow = document.querySelector(`tr[data-barcode="${scannedBarcode}"]`);
    if (assetRow) {
        const quantityCell = assetRow.cells[3];
        const statusCell = assetRow.cells[4];

        
        const currentQuantity = parseInt(quantityCell.textContent);
        if (currentQuantity > 0) {
            quantityCell.textContent = currentQuantity - 1;
            statusCell.innerHTML = '<span class="badge bg-warning">Out</span>';
        } else {
            alert("No available quantity for this asset!");
        }
    } else {
        alert("Asset not found!");
    }

    
    scannedBarcode = null;
    document.getElementById('forOutButton').disabled = true;
    document.getElementById('forReturnButton').disabled = true;
});


document.getElementById('forReturnButton')?.addEventListener('click', function () {
    if (!scannedBarcode) return;

    const assetRow = document.querySelector(`tr[data-barcode="${scannedBarcode}"]`);
    if (assetRow) {
        const quantityCell = assetRow.cells[3];
        const statusCell = assetRow.cells[4];

        const currentQuantity = parseInt(quantityCell.textContent);
        quantityCell.textContent = currentQuantity + 1;
        statusCell.innerHTML = '<span class="badge bg-success">Returned</span>';
    } else {
        alert("Asset not found!");
    }


    scannedBarcode = null;
    document.getElementById('forOutButton').disabled = true;
    document.getElementById('forReturnButton').disabled = true;
});


document.getElementById('barcodeScannerModal')?.addEventListener('shown.bs.modal', function () {
    initializeBarcodeScanner();
});


document.getElementById('barcodeScannerModal')?.addEventListener('hidden.bs.modal', function () {
    Quagga.stop();
    scannedBarcode = null;
    document.getElementById('forOutButton').disabled = true;
    document.getElementById('forReturnButton').disabled = true;
});


document.getElementById('addUserForm')?.addEventListener('submit', function(event) {
    event.preventDefault();

    const userName = document.getElementById('userName').value;
    const userEmail = document.getElementById('userEmail').value;
    const userPassword = document.getElementById('userPassword').value;
    const userRole = document.getElementById('userRole').value;

  
    const userList = document.querySelector('tbody');
    const newRow = `
        <tr>
            <td>${userName}</td>
            <td>${userEmail}</td>
            <td>********</td>
            <td>${userRole}</td>
            <td>
                <button class="btn btn-sm btn-warning me-2" data-bs-toggle="modal" data-bs-target="#editUserModal">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-sm btn-danger" onclick="deleteUser(this)">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
    `;
    userList.insertAdjacentHTML('beforeend', newRow);


    const addUserModal = bootstrap.Modal.getInstance(document.getElementById('addUserModal'));
    addUserModal.hide();

   
    event.target.reset();
});


function deleteUser(button) {
    const row = button.closest('tr');
    row.remove();
}


document.getElementById('editUserForm')?.addEventListener('submit', function(event) {
    event.preventDefault();

    const userName = document.getElementById('editUserName').value;
    const userEmail = document.getElementById('editUserEmail').value;
    const userPassword = document.getElementById('editUserPassword').value;
    const userRole = document.getElementById('editUserRole').value;

  
    const row = document.querySelector('tbody tr');
    row.cells[0].textContent = userName;
    row.cells[1].textContent = userEmail;
    row.cells[3].textContent = userRole;

    const editUserModal = bootstrap.Modal.getInstance(document.getElementById('editUserModal'));
    editUserModal.hide();

    event.target.reset();
});

function logout() {
    localStorage.removeItem('user');
    window.location.href = 'index.html';
}


document.getElementById('logoutButton')?.addEventListener('click', logout);


app.post('/register', (req, res) => {
    const { name, email, password } = req.body;


    const userExists = users.some(u => u.email === email);
    if (userExists) {
        res.json({ success: false, message: 'User already exists' });
    } else {
        users.push({ name, email, password });
        res.json({ success: true });
    }
});


app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});

// Fetch Data from Backend
async function fetchData() {
    try {
        // Fetch assets data
        const assetsResponse = await fetch('/api/assets');
        const assetsData = await assetsResponse.json();

        // Fetch users data
        const usersResponse = await fetch('/api/users');
        const usersData = await usersResponse.json();

        // Update the dashboard with fetched data
        updateDashboard(assetsData, usersData);
    } catch (error) {
        console.error("Error fetching data:", error);
    }
}

// Update Dashboard with Fetched Data
function updateDashboard(assets, users) {
    // Update Total Assets
    document.getElementById('totalAssets').textContent = assets.length;

    // Update Available Assets
    const availableAssets = assets.filter(asset => asset.status === 'Available').length;
    document.getElementById('availableAssets').textContent = availableAssets;

    // Update Total Users
    document.getElementById('totalUsers').textContent = users.length;

    // Update Low Stock
    const lowStock = assets.filter(asset => asset.quantity <= 5).length;
    document.getElementById('lowStock').textContent = lowStock;

    // Update Most Used Asset
    const mostUsedAsset = assets.reduce((prev, current) => (prev.quantity > current.quantity) ? prev : current);
    document.getElementById('mostUsedAsset').textContent = mostUsedAsset ? `${mostUsedAsset.name} (${mostUsedAsset.quantity} used)` : 'No data available.';

    // Update Top Assets Table
    const topAssetsTable = document.getElementById('topAssetsTable');
    topAssetsTable.innerHTML = assets
        .sort((a, b) => b.quantity - a.quantity)
        .slice(0, 5) // Show top 5 assets
        .map(asset => `
            <tr>
                <td>${asset.id}</td>
                <td>${asset.name}</td>
                <td>${asset.quantity}</td>
                <td><span class="badge ${asset.status === 'Available' ? 'bg-success' : 'bg-warning'}">${asset.status}</span></td>
            </tr>
        `)
        .join('');
}

// Fetch Data When the Page Loads
window.addEventListener('load', fetchData);

// Refresh Data Every 5 Seconds (Optional)
setInterval(fetchData, 5000);